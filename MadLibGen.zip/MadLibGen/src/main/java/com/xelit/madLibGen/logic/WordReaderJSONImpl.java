package com.xelit.madLibGen.logic;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.xelit.madLibGen.exceptions.ApplicationException;

public class WordReaderJSONImpl implements WordReader {

	String wordsFilePath;
	// Map of words list with key as type like noun/verb/adverb Etc.
	public WordReaderJSONImpl(String wordsFilePathJSON) {
		this.wordsFilePath = wordsFilePathJSON;
	}

	public void readWords() throws ApplicationException {
			JSONParser parser = new JSONParser();
			List<String> value = null;
	        try { 
	        	JSONArray a = (JSONArray) parser.parse(new FileReader(wordsFilePath));
	        	  for (Object o : a)
	        	  {
	        	    JSONObject jsonObject = (JSONObject) o;
	        	    String type = (String) jsonObject.get("type");
	        	    if(!words.containsKey(type)){
	        	    	value = new ArrayList<String>();
	        	    }else{
	        	    	value = words.get(type);
	        	    }
	        	    String word = (String) jsonObject.get("word");
	        	    value.add(word);
	        	    if(!words.containsKey(type)){
	        	    	 words.put(type, value);
	        	    }
	        	  }
	        } catch (FileNotFoundException e) {
	           throw new ApplicationException("WordReaderJSONImpl: File not found exception while processing words ");
	        } catch (IOException e) {
	        	 throw new ApplicationException("WordReaderJSONImpl: IO exception while processing words ");     
	        } catch (ParseException e) {
	       	 throw new ApplicationException("WordReaderJSONImpl: Parse exception while processing words ");
	  	      
	        }
	}

}
