package com.xelit.madLibGen.logic;

import com.xelit.madLibGen.exceptions.ApplicationException;

public class MadLibGenerator {

	private String wordsFileName;
	private String phrasesFileName;
	private String resultFileName;
	
	public MadLibGenerator(String wordsFileName, String phrasesFileName, String resultFileName) {
		this.wordsFileName = wordsFileName;
		this.phrasesFileName = phrasesFileName;
		this.resultFileName = resultFileName;
	}
	
	public void execute() throws ApplicationException{
		//Load words from file
		WordReader wordReader = new WordReaderJSONImpl(wordsFileName);
		wordReader.readWords();
		
		// Load phrases, replace and write 
		//[Todo: Should be divided further into single tasks]
		PhraseProcessor phraseProcessor = new PhraseProcessorTxtImpl(phrasesFileName,resultFileName);
		phraseProcessor.processPhrases();
		System.out.println("MadLib Generated Successfully!!");
		
	}

}
