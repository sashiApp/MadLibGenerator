package com.xelit.madLibGen.logic;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.xelit.madLibGen.exceptions.ApplicationException;

public interface WordReader {
	public static Map<String, List<String>> words = new HashMap<String, List<String>>();
	public void readWords() throws ApplicationException;
}
