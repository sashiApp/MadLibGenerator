package com.xelit.madLibGen.logic;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.xelit.madLibGen.exceptions.ApplicationException;



public class PhraseProcessorTxtImpl implements PhraseProcessor {
	String phrasesFilePath;
	String resultFilePath;
	public PhraseProcessorTxtImpl(String phrasesFilePath, String resultFilePath) {
		this.phrasesFilePath = phrasesFilePath;
		this.resultFilePath = resultFilePath;
	}
	public void processPhrases() throws ApplicationException {
		Path path = Paths.get(phrasesFilePath);
		BufferedReader reader;
		Random random = new Random();
		int size = 0;
		BufferedWriter writer = null;
		try {
			//Read phrases from file
			reader = Files.newBufferedReader(path, StandardCharsets.UTF_8);
			//Open writer to write into output file
			writer = new BufferedWriter(new FileWriter(new File(resultFilePath)));	     
			
			
			for (String line = reader.readLine(); line != null;  line = reader.readLine()) {
				 Pattern p = Pattern.compile("\\[(.*?)\\]");
				 Matcher m = p.matcher(line);
				 StringBuffer phrases = new StringBuffer();
			       while(m.find()) {
			    	   if(WordReader.words.containsKey(m.group(1))){
			    		   size = WordReader.words.get(m.group(1)).size();
			    		   m.appendReplacement(phrases,WordReader.words.get(m.group(1)).get(random.nextInt(size)));
						      
			    	   }
			         }
			         writer.write(phrases.toString());
			         writer.write("\n");
			}
		}catch(Exception e){
			throw new ApplicationException("PhrasewriterTxtImpl: Unknown exception:"+e);	
		}finally{
			try {
				writer.close();
			} catch (IOException e) {
				throw new ApplicationException("PhraseProcessorTxtImpl: Exception while closing BufferWriter");
			}
		}
	}

}
