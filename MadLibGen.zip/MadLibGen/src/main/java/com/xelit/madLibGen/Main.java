package com.xelit.madLibGen;
import java.util.Scanner;
import com.xelit.madLibGen.exceptions.ApplicationException;
import com.xelit.madLibGen.logic.MadLibGenerator;
import com.xelit.madLibGen.util.Validator;

public class Main {

	public static void main(String[] args) {
		try{
				Scanner in = new Scanner(System.in);
				System.out.println("Enter the words file path:");
				String wordsFile = in.nextLine();
				if(!Validator.isValidFilePath(wordsFile)){
					throw new ApplicationException("Main: Invaid file name");
				}
				System.out.println("Enter the phrases file path:");
				String phrasesFile = in.nextLine();
				if(!Validator.isValidFilePath(phrasesFile)){
					throw new ApplicationException("Main: Invaid file name");
				}
				System.out.println("Enter the output file path:");
				String outputFile = in.nextLine();
				if(!Validator.isValidFilename(outputFile)){
					throw new ApplicationException("Main: Invaid file name");
				}
				MadLibGenerator madLibGenerator = new MadLibGenerator(wordsFile,phrasesFile,outputFile);
				madLibGenerator.execute();
		}catch(ApplicationException ae){
			System.out.println("Application Exception:"+ae);
		}catch(Exception e){
			System.out.println("Unknown Exception:"+e);
		}
		
		

	}

}
