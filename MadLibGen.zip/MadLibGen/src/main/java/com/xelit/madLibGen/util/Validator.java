package com.xelit.madLibGen.util;

import java.nio.file.Files;
import java.nio.file.Paths;

public class Validator {

	public Validator() {
		// TODO Auto-generated constructor stub
	}
	public static boolean isValidFilename(String fileName){
		if(fileName == null || fileName.trim().equals("")){
			return false;
		}
		return true;
	}
	public static boolean isValidFilePath(String fileName){
		if(fileName == null || fileName.trim().equals("")){
			return false;
		}
		if(!isValidFilename(fileName) || !Files.exists(Paths.get(fileName))){
			return false;
		}
		return true;
	}

}
