package com.xelit.madLibGen.logic;

import com.xelit.madLibGen.exceptions.ApplicationException;

public interface PhraseProcessor {
	public void processPhrases() throws ApplicationException;
}
