### Execute Jar 
The Exeutable jar (MadLibGen.jar) can be downloaded and placed in a folder

If The machine contains valid Java installation, the following command runs the application in command prompt

java -jar jar-file-path


#### Source

Attached eclipse workspace in Zip file. 

The project can be imported from eclipse, by selecting import existing maven project option.

### Unit tests not covered.